import { Component }      from '@angular/core';

// This component consumes the re-usable service.
@Component({
    template: "404"
})
export class PageDefault {
}